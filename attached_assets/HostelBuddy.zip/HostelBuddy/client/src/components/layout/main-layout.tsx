import { useState } from "react";
import Sidebar from "./sidebar";
import Header from "./header";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header onMobileMenuToggle={toggleMobileMenu} />
      
      <div className="flex min-h-screen pt-16">
        <Sidebar isMobileMenuOpen={isMobileMenuOpen} />
        
        <div className="md:ml-64 w-full p-4 sm:p-6 lg:p-8">
          {children}
        </div>
      </div>
    </div>
  );
}
