import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard,
  CalendarPlus,
  FileText,
  CheckSquare,
  XSquare,
  Home,
  User,
  LogOut
} from "lucide-react";

interface SidebarProps {
  isMobileMenuOpen: boolean;
}

export default function Sidebar({ isMobileMenuOpen }: SidebarProps) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const renderUserNav = () => (
    <>
      <Link href="/">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          isActive("/") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <LayoutDashboard className="mr-3 h-5 w-5" />
          Dashboard
        </a>
      </Link>
      <Link href="/new-booking">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          isActive("/new-booking") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <CalendarPlus className="mr-3 h-5 w-5" />
          New Booking
        </a>
      </Link>
      <Link href="/bookings">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          isActive("/bookings") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <FileText className="mr-3 h-5 w-5" />
          My Bookings
        </a>
      </Link>
    </>
  );

  const renderAdminNav = () => (
    <>
      <Link href="/admin">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          isActive("/admin") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <LayoutDashboard className="mr-3 h-5 w-5" />
          Dashboard
        </a>
      </Link>
      <Link href="/admin?filter=pending">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          location.includes("pending") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <FileText className="mr-3 h-5 w-5" />
          Pending Requests
        </a>
      </Link>
      <Link href="/admin?filter=approved">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          location.includes("approved") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <CheckSquare className="mr-3 h-5 w-5" />
          Approved Requests
        </a>
      </Link>
      <Link href="/admin?filter=rejected">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          location.includes("rejected") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <XSquare className="mr-3 h-5 w-5" />
          Rejected Requests
        </a>
      </Link>
    </>
  );

  const renderVFastNav = () => (
    <>
      <Link href="/vfast">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          isActive("/vfast") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <LayoutDashboard className="mr-3 h-5 w-5" />
          Dashboard
        </a>
      </Link>
      <Link href="/vfast?filter=pending">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          location.includes("pending") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <Home className="mr-3 h-5 w-5" />
          Room Allocation
        </a>
      </Link>
      <Link href="/vfast?filter=allocated">
        <a className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md",
          location.includes("allocated") 
            ? "bg-neutral-100 text-primary" 
            : "text-neutral-600 hover:bg-neutral-50 hover:text-primary"
        )}>
          <CheckSquare className="mr-3 h-5 w-5" />
          Finalized Bookings
        </a>
      </Link>
    </>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <div className="hidden md:flex md:flex-col md:w-64 md:min-h-screen border-r border-neutral-200 bg-white">
        <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
          <nav className="mt-5 flex-1 px-2 space-y-1">
            {user?.role === "admin" ? renderAdminNav() : 
             user?.role === "vfast" ? renderVFastNav() : 
             renderUserNav()}
          </nav>
          <div className="border-t border-neutral-200 p-4">
            <button 
              onClick={handleLogout}
              className="flex items-center text-neutral-600 hover:text-primary group text-sm font-medium"
            >
              <LogOut className="mr-3 h-5 w-5 text-neutral-500 group-hover:text-primary" />
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Mobile sidebar */}
      <div className={`md:hidden fixed inset-0 z-40 ${isMobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="fixed inset-0 bg-neutral-600 bg-opacity-75"></div>
        <div className="relative flex-1 flex flex-col max-w-xs w-full pt-5 pb-4 bg-white">
          <div className="absolute top-0 right-0 -mr-12 pt-2">
            <button className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
              <span className="sr-only">Close sidebar</span>
              <XSquare className="h-6 w-6 text-white" />
            </button>
          </div>
          <div className="flex-shrink-0 flex items-center px-4">
            <img 
              className="h-8 w-auto" 
              src="https://www.bits-pilani.ac.in/Uploads/University/GJCampus/3-column-content/logo-dark.svg" 
              alt="BITS Pilani Logo" 
            />
          </div>
          <div className="mt-5 flex-1 h-0 overflow-y-auto">
            <nav className="px-2 space-y-1">
              {user?.role === "admin" ? renderAdminNav() : 
               user?.role === "vfast" ? renderVFastNav() : 
               renderUserNav()}
            </nav>
          </div>
          <div className="border-t border-neutral-200 p-4">
            <button 
              onClick={handleLogout}
              className="flex items-center text-neutral-600 hover:text-primary group text-sm font-medium"
            >
              <LogOut className="mr-3 h-5 w-5 text-neutral-500 group-hover:text-primary" />
              Logout
            </button>
          </div>
        </div>
        <div className="flex-shrink-0 w-14" aria-hidden="true">
          {/* Placeholder to force sidebar to shrink to fit close icon */}
        </div>
      </div>
    </>
  );
}
