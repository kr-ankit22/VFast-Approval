
import { Booking, BookingStatus } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building, Calendar, User, ClipboardList, MessageCircle } from "lucide-react";
import { format, parseISO } from "date-fns";

interface BookingCardProps {
  booking: Booking;
}

export default function BookingCard({ booking }: BookingCardProps) {
  // Get friendly accommodation name from purpose
  const getAccommodationName = (purpose: string) => {
    switch (purpose) {
      case "academic":
        return "Faculty Guest House";
      case "conference":
        return "Visitor's Hostel";
      case "personal":
        return "Guest House";
      case "project":
        return "Faculty Guest House";
      default:
        return "Visitor's Hostel";
    }
  };

  // Get status badge based on booking status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case BookingStatus.PENDING:
        return <Badge variant="outline" className="status-badge status-pending">Pending Approval</Badge>;
      case BookingStatus.APPROVED:
        return <Badge variant="outline" className="status-badge status-approved">Approved</Badge>;
      case BookingStatus.REJECTED:
        return <Badge variant="outline" className="status-badge status-rejected">Rejected</Badge>;
      case BookingStatus.ALLOCATED:
        return <Badge variant="outline" className="status-badge status-allocated">Confirmed</Badge>;
      case BookingStatus.CANCELLED:
        return <Badge variant="outline" className="status-badge status-cancelled">Cancelled</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow duration-200">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 px-4 py-4 sm:px-6">
        {/* Left column - Main booking info */}
        <div className="md:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Building className="h-5 w-5 text-primary" />
              <p className="text-sm font-medium text-primary truncate">
                {getAccommodationName(booking.purpose)}
              </p>
            </div>
            <div>
              {getStatusBadge(booking.status)}
            </div>
          </div>
          
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            <div className="flex items-center text-sm text-gray-500">
              <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
              <p>
                {format(parseISO(booking.checkIn), "MMM dd")} - {format(parseISO(booking.checkOut), "MMM dd, yyyy")}
              </p>
            </div>
            
            <div className="flex items-center text-sm text-gray-500">
              <User className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
              <p>
                {booking.userType === "internal" ? "BITS Internal" : "External"} · {booking.department}
              </p>
            </div>

            {booking.roomNumber && (
              <div className="flex items-center text-sm text-gray-500">
                <ClipboardList className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                <p>
                  Room: <span className="font-medium text-gray-900">{booking.roomNumber}</span>
                </p>
              </div>
            )}
          </div>
          
          {booking.comments && (
            <div className="mt-2 text-sm">
              <p className="text-xs text-gray-500">User comments:</p>
              <p className="text-gray-700 line-clamp-2">{booking.comments}</p>
            </div>
          )}
        </div>
        
        {/* Right column - Notes section */}
        <div className="border-t pt-3 md:pt-0 md:border-t-0 md:border-l md:pl-4 md:ml-2 mt-2 md:mt-0">
          {(booking.adminNote || booking.vfastNote) ? (
            <div className="space-y-2">
              {booking.adminNote && (
                <div className="text-sm">
                  <div className="flex items-center">
                    <MessageCircle className="h-3.5 w-3.5 text-amber-500 mr-1" />
                    <p className="text-xs font-medium text-gray-500">Admin note:</p>
                  </div>
                  <p className="text-gray-700 ml-5 line-clamp-3">{booking.adminNote}</p>
                </div>
              )}
              
              {booking.vfastNote && (
                <div className="text-sm">
                  <div className="flex items-center">
                    <MessageCircle className="h-3.5 w-3.5 text-blue-500 mr-1" />
                    <p className="text-xs font-medium text-gray-500">VFast note:</p>
                  </div>
                  <p className="text-gray-700 ml-5 line-clamp-3">{booking.vfastNote}</p>
                </div>
              )}
            </div>
          ) : (
            <div className="flex h-full items-center justify-center text-xs text-gray-400">
              No additional notes
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
