import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Booking } from "@shared/schema";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import BookingCard from "@/components/booking-card";
import { CalendarPlus, FileText, CheckCircle, Clock } from "lucide-react";
import { Loader2 } from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Fetch user's bookings
  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: ["/api/bookings/user"],
  });

  // Redirect to role-specific dashboard
  if (user?.role === "admin") {
    setLocation("/admin");
    return null;
  } else if (user?.role === "vfast") {
    setLocation("/vfast");
    return null;
  }

  // Calculate booking statistics
  const totalBookings = bookings?.length || 0;
  const pendingBookings = bookings?.filter(b => b.status === "pending").length || 0;
  const confirmedBookings = bookings?.filter(b => 
    b.status === "approved" || b.status === "allocated"
  ).length || 0;

  return (
    <MainLayout>
      <div className="flex flex-col min-h-0 flex-1">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900 sm:text-3xl">
            Welcome, {user?.name?.split(' ')[0]}
          </h1>
          <Button asChild className="hidden sm:flex">
            <Link to="/new-booking">
              <CalendarPlus className="mr-2 h-4 w-4" />
              New Booking
            </Link>
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 mb-6">
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-primary rounded-md p-3">
                  <FileText className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Total Bookings</dt>
                    <dd className="text-3xl font-semibold text-gray-900">{totalBookings}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-amber-500 rounded-md p-3">
                  <Clock className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Pending Bookings</dt>
                    <dd className="text-3xl font-semibold text-gray-900">{pendingBookings}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-green-500 rounded-md p-3">
                  <CheckCircle className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Confirmed Bookings</dt>
                    <dd className="text-3xl font-semibold text-gray-900">{confirmedBookings}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Bookings */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium text-gray-900">Recent Bookings</h2>
            <Button variant="outline" asChild>
              <Link to="/bookings">View All</Link>
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : bookings && bookings.length > 0 ? (
            <div className="space-y-4">
              {bookings.slice(0, 5).map((booking) => (
                <BookingCard key={booking.id} booking={booking} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center p-8 text-center">
                <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No bookings yet</h3>
                <p className="text-sm text-muted-foreground mb-4">You haven't made any bookings yet.</p>
                <Button asChild>
                  <Link to="/new-booking">
                    <CalendarPlus className="mr-2 h-4 w-4" />
                    Create your first booking
                  </Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
