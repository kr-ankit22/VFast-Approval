import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Booking, BookingStatus, RoomAllocation } from "@shared/schema";
import MainLayout from "@/components/layout/main-layout";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Eye, Home, AlertTriangle } from "lucide-react";
import { format } from "date-fns";

// Sample room numbers for demo
const roomOptions = [
  "FGH-101", "FGH-102", "FGH-103", "FGH-104", "FGH-105",
  "VH-201", "VH-202", "VH-203", "VH-204", "VH-205"
];

export default function VFastDashboard() {
  const { toast } = useToast();
  const [location] = useLocation();
  const [activeTab, setActiveTab] = useState("pending");
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [allocateDialogOpen, setAllocateDialogOpen] = useState(false);
  const [roomNumber, setRoomNumber] = useState("");
  
  // Parse URL query parameters
  useEffect(() => {
    // Check if URL contains a filter parameter
    const params = new URLSearchParams(location.split('?')[1]);
    const filterParam = params.get('filter');
    
    if (filterParam) {
      // Set active tab based on the filter param
      if (['all', 'pending', 'allocated'].includes(filterParam)) {
        setActiveTab(filterParam);
      }
    }
  }, [location]);

  // Fetch approved bookings
  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
  });

  // Room allocation mutation
  const allocateRoomMutation = useMutation({
    mutationFn: async (data: RoomAllocation) => {
      const res = await apiRequest("PUT", `/api/bookings/${data.bookingId}/allocate`, data);
      return res.json();
    },
    onSuccess: (updatedBooking) => {
      // Force refetch to ensure we get the latest data
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      // Immediately update the booking in the cache to reflect changes
      queryClient.setQueryData(["/api/bookings"], (oldData: Booking[] | undefined) => {
        if (!oldData) return oldData;
        return oldData.map(booking => 
          booking.id === updatedBooking.id ? updatedBooking : booking
        );
      });
      
      setAllocateDialogOpen(false);
      setRoomNumber("");
      setSelectedBooking(null);
      toast({
        title: "Room allocated",
        description: "The room has been successfully allocated to the booking.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Allocation failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Filter bookings based on active tab
  const filteredBookings = bookings?.filter(booking => {
    switch (activeTab) {
      case "all":
        return true; // Show all approved/allocated bookings
      case "pending":
        return !booking.roomNumber && booking.status === BookingStatus.APPROVED; // Only approved bookings without rooms
      case "allocated":
        return booking.roomNumber !== null || booking.status === BookingStatus.ALLOCATED; // Only bookings with rooms or ALLOCATED status
      default:
        return false;
    }
  });

  // Handle room allocation
  const handleAllocateRoom = () => {
    if (!selectedBooking || !roomNumber) return;
    
    allocateRoomMutation.mutate({
      bookingId: selectedBooking.id,
      roomNumber: roomNumber
    });
  };

  // Get status badge
  const getStatusBadge = (status: string, roomNumber: string | null) => {
    if (status === BookingStatus.APPROVED && !roomNumber) {
      return <Badge variant="outline" className="status-badge status-pending">Pending Allocation</Badge>;
    } else if (status === BookingStatus.ALLOCATED || (status === BookingStatus.APPROVED && roomNumber)) {
      return <Badge variant="outline" className="status-badge status-allocated">Room Allocated</Badge>;
    }
    return <Badge variant="outline">Unknown</Badge>;
  };

  return (
    <MainLayout>
      <div className="flex flex-col min-h-0 flex-1">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">VFast Dashboard</h1>
        </div>

        <Tabs defaultValue="pending" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Requests</TabsTrigger>
            <TabsTrigger value="pending">Pending Allocation</TabsTrigger>
            <TabsTrigger value="allocated">Room Allocated</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab}>
            {isLoading ? (
              <div className="flex justify-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredBookings && filteredBookings.length > 0 ? (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User ID</TableHead>
                      <TableHead>User Type</TableHead>
                      <TableHead>Stay Details</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Room</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell className="font-medium">{booking.userId}</TableCell>
                        <TableCell>{booking.userType}</TableCell>
                        <TableCell>
                          <div>{`${format(new Date(booking.checkIn), "MMM dd, yyyy")} - ${format(new Date(booking.checkOut), "MMM dd, yyyy")}`}</div>
                          <div className="text-sm text-muted-foreground">{booking.purpose}</div>
                        </TableCell>
                        <TableCell>{booking.department}</TableCell>
                        <TableCell>
                          {booking.roomNumber ? booking.roomNumber : "Not Allocated"}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(booking.status, booking.roomNumber)}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setSelectedBooking(booking);
                                setDialogOpen(true);
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            
                            {booking.status === BookingStatus.APPROVED && !booking.roomNumber && (
                              <Button 
                                variant="ghost" 
                                size="icon"
                                className="text-primary hover:text-primary-dark hover:bg-primary-50"
                                onClick={() => {
                                  setSelectedBooking(booking);
                                  setRoomNumber("");
                                  setAllocateDialogOpen(true);
                                }}
                              >
                                <Home className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center p-8 text-center border rounded-md">
                <AlertTriangle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No bookings found</h3>
                <p className="text-sm text-muted-foreground">
                  {activeTab === "all"
                    ? "There are no approved booking requests."
                    : activeTab === "pending"
                      ? "There are no pending room allocations."
                      : "There are no allocated rooms."}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* View booking details dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Booking Details</DialogTitle>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">User ID</p>
                  <p>{selectedBooking.userId}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">User Type</p>
                  <p>{selectedBooking.userType}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Check-in</p>
                  <p>{format(new Date(selectedBooking.checkIn), "MMM dd, yyyy")}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Check-out</p>
                  <p>{format(new Date(selectedBooking.checkOut), "MMM dd, yyyy")}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Purpose</p>
                  <p>{selectedBooking.purpose}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Department</p>
                  <p>{selectedBooking.department}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <p>{getStatusBadge(selectedBooking.status, selectedBooking.roomNumber)}</p>
                </div>
                {selectedBooking.roomNumber && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Room Number</p>
                    <p>{selectedBooking.roomNumber}</p>
                  </div>
                )}
              </div>
              
              {selectedBooking.comments && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Comments</p>
                  <p className="mt-1">{selectedBooking.comments}</p>
                </div>
              )}
              
              {selectedBooking.adminNote && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Admin Note</p>
                  <p className="mt-1">{selectedBooking.adminNote}</p>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Allocate room dialog */}
      <Dialog open={allocateDialogOpen} onOpenChange={setAllocateDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Allocate Room</DialogTitle>
            <DialogDescription>
              Select a room number to allocate to this booking.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="space-y-4">
            <Label>Available Rooms</Label>
            <div className="grid grid-cols-6 gap-2 max-h-[400px] overflow-y-auto p-2">
              {/* FGH building rooms (101-110) */}
              {Array.from({ length: 10 }, (_, i) => {
                const roomNum = `FGH-${String(i + 101).padStart(3, '0')}`;
                const isAllocated = bookings?.some(b => 
                  b.roomNumber === roomNum && 
                  b.status !== BookingStatus.REJECTED &&
                  (selectedBooking && 
                    (new Date(b.checkOut) >= new Date(selectedBooking.checkIn) &&
                     new Date(b.checkIn) <= new Date(selectedBooking.checkOut))
                  )
                );
                
                return (
                  <button
                    key={roomNum}
                    onClick={() => !isAllocated && setRoomNumber(roomNum)}
                    className={`p-2 rounded-md text-sm font-medium transition-colors
                      ${isAllocated 
                        ? 'bg-red-100 text-red-700 cursor-not-allowed'
                        : roomNumber === roomNum
                          ? 'bg-green-500 text-white'
                          : 'bg-green-100 text-green-700 hover:bg-green-200'
                      }`}
                    disabled={isAllocated}
                    title={isAllocated ? 'Room already allocated' : 'Available'}
                  >
                    {roomNum}
                  </button>
                );
              })}
              
              {/* VH building rooms (201-210) */}
              {Array.from({ length: 10 }, (_, i) => {
                const roomNum = `VH-${String(i + 201).padStart(3, '0')}`;
                const isAllocated = bookings?.some(b => 
                  b.roomNumber === roomNum && 
                  b.status !== BookingStatus.REJECTED &&
                  (selectedBooking && 
                    (new Date(b.checkOut) >= new Date(selectedBooking.checkIn) &&
                     new Date(b.checkIn) <= new Date(selectedBooking.checkOut))
                  )
                );
                
                return (
                  <button
                    key={roomNum}
                    onClick={() => !isAllocated && setRoomNumber(roomNum)}
                    className={`p-2 rounded-md text-sm font-medium transition-colors
                      ${isAllocated 
                        ? 'bg-red-100 text-red-700 cursor-not-allowed'
                        : roomNumber === roomNum
                          ? 'bg-green-500 text-white'
                          : 'bg-green-100 text-green-700 hover:bg-green-200'
                      }`}
                    disabled={isAllocated}
                    title={isAllocated ? 'Room already allocated' : 'Available'}
                  >
                    {roomNum}
                  </button>
                );
              })}
            </div>
            {roomNumber && (
              <p className="text-sm text-muted-foreground">
                Selected Room: {roomNumber}
              </p>
            )}
          </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setAllocateDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleAllocateRoom}
              disabled={allocateRoomMutation.isPending || !roomNumber}
              className="bg-primary hover:bg-[#0066b8]"
            >
              {allocateRoomMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : "Allocate Room"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
