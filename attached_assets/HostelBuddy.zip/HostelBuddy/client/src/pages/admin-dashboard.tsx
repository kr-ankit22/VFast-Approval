import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Booking, BookingApproval, BookingStatus } from "@shared/schema";
import MainLayout from "@/components/layout/main-layout";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, Eye, Check, X, AlertTriangle, RotateCcw } from "lucide-react";
import { format } from "date-fns";

export default function AdminDashboard() {
  const { toast } = useToast();
  const [location] = useLocation();
  const [activeTab, setActiveTab] = useState("all");
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [approveDialogOpen, setApproveDialogOpen] = useState(false);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [reconsiderDialogOpen, setReconsiderDialogOpen] = useState(false);
  const [adminNote, setAdminNote] = useState("");
  
  // Parse URL query parameters
  useEffect(() => {
    // Check if URL contains a filter parameter
    const params = new URLSearchParams(location.split('?')[1]);
    const filterParam = params.get('filter');
    
    if (filterParam) {
      // Set active tab based on the filter param
      if (['all', 'pending', 'approved', 'rejected'].includes(filterParam)) {
        setActiveTab(filterParam);
      }
    }
  }, [location]);

  // Fetch all bookings
  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
  });

  // Booking approval/rejection mutation
  const updateStatusMutation = useMutation({
    mutationFn: async (data: BookingApproval) => {
      const res = await apiRequest("PUT", `/api/bookings/${data.bookingId}/status`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      setApproveDialogOpen(false);
      setRejectDialogOpen(false);
      setReconsiderDialogOpen(false);
      setAdminNote("");
      setSelectedBooking(null);
      toast({
        title: "Booking updated",
        description: "The booking status has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Filter bookings based on active tab
  const filteredBookings = bookings?.filter(booking => {
    if (activeTab === "all") return true;
    if (activeTab === "pending") return booking.status === BookingStatus.PENDING;
    if (activeTab === "approved") return booking.status === BookingStatus.APPROVED || booking.status === BookingStatus.ALLOCATED;
    if (activeTab === "rejected") return booking.status === BookingStatus.REJECTED;
    return true;
  });

  // Handle approve booking
  const handleApprove = () => {
    if (!selectedBooking) return;
    
    updateStatusMutation.mutate({
      bookingId: selectedBooking.id,
      status: BookingStatus.APPROVED,
      adminNote: adminNote
    });
  };

  // Handle reject booking
  const handleReject = () => {
    if (!selectedBooking) return;
    
    updateStatusMutation.mutate({
      bookingId: selectedBooking.id,
      status: BookingStatus.REJECTED,
      adminNote: adminNote
    });
  };
  
  // Handle reconsider booking (move back to pending)
  const handleReconsider = () => {
    if (!selectedBooking) return;
    
    updateStatusMutation.mutate({
      bookingId: selectedBooking.id,
      status: "pending" as any, // Type assertion to bypass the type check
      adminNote: adminNote
    });
  };

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case BookingStatus.PENDING:
        return <Badge variant="outline" className="status-badge status-pending">Pending</Badge>;
      case BookingStatus.APPROVED:
        return <Badge variant="outline" className="status-badge status-approved">Approved</Badge>;
      case BookingStatus.REJECTED:
        return <Badge variant="outline" className="status-badge status-rejected">Rejected</Badge>;
      case BookingStatus.ALLOCATED:
        return <Badge variant="outline" className="status-badge status-allocated">Allocated</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <MainLayout>
      <div className="flex flex-col min-h-0 flex-1">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Requests</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="approved">Approved</TabsTrigger>
            <TabsTrigger value="rejected">Rejected</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab}>
            {isLoading ? (
              <div className="flex justify-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredBookings && filteredBookings.length > 0 ? (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User ID</TableHead>
                      <TableHead>User Type</TableHead>
                      <TableHead>Stay Details</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell className="font-medium">{booking.userId}</TableCell>
                        <TableCell>{booking.userType}</TableCell>
                        <TableCell>
                          <div>{`${format(new Date(booking.checkIn), "MMM dd, yyyy")} - ${format(new Date(booking.checkOut), "MMM dd, yyyy")}`}</div>
                          <div className="text-sm text-muted-foreground">{booking.purpose}</div>
                        </TableCell>
                        <TableCell>{booking.department}</TableCell>
                        <TableCell>{getStatusBadge(booking.status)}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setSelectedBooking(booking);
                                setDialogOpen(true);
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            
                            {booking.status === BookingStatus.PENDING && (
                              <>
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  className="text-green-600 hover:text-green-700 hover:bg-green-50"
                                  onClick={() => {
                                    setSelectedBooking(booking);
                                    setApproveDialogOpen(true);
                                  }}
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                                
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => {
                                    setSelectedBooking(booking);
                                    setRejectDialogOpen(true);
                                  }}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                            
                            {booking.status === BookingStatus.REJECTED && (
                              <Button 
                                variant="ghost" 
                                size="icon"
                                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                onClick={() => {
                                  setSelectedBooking(booking);
                                  setReconsiderDialogOpen(true);
                                }}
                              >
                                <RotateCcw className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center p-8 text-center border rounded-md">
                <AlertTriangle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No bookings found</h3>
                <p className="text-sm text-muted-foreground">
                  {activeTab === "all"
                    ? "There are no booking requests in the system."
                    : `There are no ${activeTab} booking requests.`}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* View booking details dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Booking Details</DialogTitle>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">User ID</p>
                  <p>{selectedBooking.userId}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">User Type</p>
                  <p>{selectedBooking.userType}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Check-in</p>
                  <p>{format(new Date(selectedBooking.checkIn), "MMM dd, yyyy")}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Check-out</p>
                  <p>{format(new Date(selectedBooking.checkOut), "MMM dd, yyyy")}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Purpose</p>
                  <p>{selectedBooking.purpose}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Department</p>
                  <p>{selectedBooking.department}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <p>{getStatusBadge(selectedBooking.status)}</p>
                </div>
                {selectedBooking.roomNumber && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Room Number</p>
                    <p>{selectedBooking.roomNumber}</p>
                  </div>
                )}
              </div>
              
              {selectedBooking.comments && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Comments</p>
                  <p className="mt-1">{selectedBooking.comments}</p>
                </div>
              )}
              
              {selectedBooking.adminNote && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Admin Note</p>
                  <p className="mt-1">{selectedBooking.adminNote}</p>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approve booking dialog */}
      <Dialog open={approveDialogOpen} onOpenChange={setApproveDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Approve Booking Request</DialogTitle>
            <DialogDescription>
              Are you sure you want to approve this booking request?
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <Textarea
              placeholder="Add an optional note (visible to VFast admins)"
              className="min-h-[100px]"
              value={adminNote}
              onChange={(e) => setAdminNote(e.target.value)}
            />
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setApproveDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleApprove}
              disabled={updateStatusMutation.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              {updateStatusMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : "Approve"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject booking dialog */}
      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reject Booking Request</DialogTitle>
            <DialogDescription>
              Are you sure you want to reject this booking request?
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <Textarea
              placeholder="Please provide a reason for rejection (visible to the user)"
              className="min-h-[100px]"
              value={adminNote}
              onChange={(e) => setAdminNote(e.target.value)}
            />
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setRejectDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleReject}
              disabled={updateStatusMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {updateStatusMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reconsider booking dialog */}
      <Dialog open={reconsiderDialogOpen} onOpenChange={setReconsiderDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reconsider Booking Request</DialogTitle>
            <DialogDescription>
              This will move the request back to pending status for review.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <Textarea
              placeholder="Add a note about why you're reconsidering this request"
              className="min-h-[100px]"
              value={adminNote}
              onChange={(e) => setAdminNote(e.target.value)}
            />
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setReconsiderDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleReconsider}
              disabled={updateStatusMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {updateStatusMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : "Move to Pending"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
