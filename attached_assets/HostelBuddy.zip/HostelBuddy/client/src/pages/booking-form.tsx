import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { InsertBooking, UserType, StayPurpose, Department } from "@shared/schema";
import MainLayout from "@/components/layout/main-layout";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarIcon, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";

// Create booking form schema
const bookingFormSchema = z.object({
  userType: z.string().min(1, "User type is required"),
  checkIn: z.string().min(1, "Check-in date is required"),
  checkOut: z.string().min(1, "Check-out date is required"),
  purpose: z.string().min(1, "Purpose of stay is required"),
  department: z.string().min(1, "Referring department is required"),
  comments: z.string().optional()
}).refine(data => {
  const checkIn = new Date(data.checkIn);
  const checkOut = new Date(data.checkOut);
  return checkOut > checkIn;
}, {
  message: "Check-out date must be after check-in date",
  path: ["checkOut"] 
});

type BookingFormValues = z.infer<typeof bookingFormSchema>;

export default function BookingForm() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  // Format dates to avoid timezone issues
  const formatDateForForm = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const todayFormatted = formatDateForForm(today);
  const tomorrowFormatted = formatDateForForm(tomorrow);
  
  const [checkInDate, setCheckInDate] = useState<Date | undefined>(today);
  const [checkOutDate, setCheckOutDate] = useState<Date | undefined>(tomorrow);

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      userType: UserType.INTERNAL,
      checkIn: todayFormatted,
      checkOut: tomorrowFormatted,
      purpose: StayPurpose.ACADEMIC,
      department: Department.CS,
      comments: ""
    }
  });

  // Booking mutation
  const bookingMutation = useMutation({
    mutationFn: async (bookingData: InsertBooking) => {
      const res = await apiRequest("POST", "/api/bookings", bookingData);
      
      // Check if the response is not OK and handle properly
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to submit booking request");
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings/user"] });
      toast({
        title: "Booking request submitted",
        description: "Your booking request has been successfully submitted.",
      });
      setLocation("/bookings");
    },
    onError: (error: Error) => {
      toast({
        title: "Booking request failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Handle form submission
  function onSubmit(data: BookingFormValues) {
    bookingMutation.mutate(data as InsertBooking);
  }

  return (
    <MainLayout>
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">New Booking Request</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Booking Details</CardTitle>
            <CardDescription>
              Fill in the details to request a new hostel booking.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="userType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>User Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select user type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value={UserType.INTERNAL}>BITS Internal</SelectItem>
                            <SelectItem value={UserType.EXTERNAL}>External</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="department"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Referring Department</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select department" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value={Department.CS}>Computer Science</SelectItem>
                            <SelectItem value={Department.EEE}>Electrical & Electronics</SelectItem>
                            <SelectItem value={Department.MECH}>Mechanical</SelectItem>
                            <SelectItem value={Department.CHEM}>Chemical</SelectItem>
                            <SelectItem value={Department.ECO}>Economics & Finance</SelectItem>
                            <SelectItem value={Department.OTHER}>Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="checkIn"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Check-in Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(new Date(field.value), "PPP")
                                ) : (
                                  <span>Select check-in date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={checkInDate}
                              onSelect={(date) => {
                                setCheckInDate(date);
                                if (date) {
                                  // Create a date string that preserves the selected date
                                  const selectedYear = date.getFullYear();
                                  const selectedMonth = String(date.getMonth() + 1).padStart(2, '0');
                                  const selectedDay = String(date.getDate()).padStart(2, '0');
                                  const dateStr = `${selectedYear}-${selectedMonth}-${selectedDay}`;
                                  
                                  field.onChange(dateStr);
                                  
                                  // Adjust checkout date if it's before or equal to the new check-in date
                                  const checkOutValue = form.getValues("checkOut");
                                  const checkOutDate = checkOutValue ? new Date(checkOutValue) : null;
                                  
                                  if (checkOutDate && checkOutDate <= date) {
                                    const nextDay = new Date(date);
                                    nextDay.setDate(nextDay.getDate() + 1);
                                    
                                    const nextYear = nextDay.getFullYear();
                                    const nextMonth = String(nextDay.getMonth() + 1).padStart(2, '0');
                                    const nextDayNum = String(nextDay.getDate()).padStart(2, '0');
                                    const nextDateStr = `${nextYear}-${nextMonth}-${nextDayNum}`;
                                    
                                    setCheckOutDate(nextDay);
                                    form.setValue("checkOut", nextDateStr);
                                  }
                                }
                              }}
                              disabled={(date) => date < new Date()}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="checkOut"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Check-out Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(new Date(field.value), "PPP")
                                ) : (
                                  <span>Select check-out date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={checkOutDate}
                              onSelect={(date) => {
                                setCheckOutDate(date);
                                if (date) {
                                  // Create a date string that preserves the selected date
                                  const selectedYear = date.getFullYear();
                                  const selectedMonth = String(date.getMonth() + 1).padStart(2, '0');
                                  const selectedDay = String(date.getDate()).padStart(2, '0');
                                  const dateStr = `${selectedYear}-${selectedMonth}-${selectedDay}`;
                                  
                                  field.onChange(dateStr);
                                }
                              }}
                              disabled={(date) => 
                                date < new Date() || 
                                (checkInDate ? date <= checkInDate : false)
                              }
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="purpose"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Purpose of Stay</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select purpose" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value={StayPurpose.ACADEMIC}>Academic Visit</SelectItem>
                            <SelectItem value={StayPurpose.CONFERENCE}>Conference</SelectItem>
                            <SelectItem value={StayPurpose.PERSONAL}>Personal Visit</SelectItem>
                            <SelectItem value={StayPurpose.PROJECT}>Project Work</SelectItem>
                            <SelectItem value={StayPurpose.OTHER}>Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="comments"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Comments</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Any special requirements or information" 
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end">
                  <Button 
                    type="submit" 
                    className="bg-primary hover:bg-[#0066b8]"
                    disabled={bookingMutation.isPending}
                  >
                    {bookingMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Submitting...
                      </>
                    ) : "Submit Request"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
