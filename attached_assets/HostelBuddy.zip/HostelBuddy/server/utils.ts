
/**
 * Utilities for date handling to ensure consistent behavior
 * throughout the application
 */

/**
 * Validate if a string is in YYYY-MM-DD format
 */
export function isValidDateFormat(dateStr: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(dateStr);
}

/**
 * Parse a date string to a Date object with consistent behavior
 * Uses UTC to avoid timezone issues
 */
export function parseDate(dateStr: string): Date {
  // Add time component if not present to ensure consistent parsing
  if (isValidDateFormat(dateStr)) {
    return new Date(dateStr + 'T00:00:00Z');
  }
  return new Date(dateStr);
}

/**
 * Format a Date object to YYYY-MM-DD format
 */
export function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

/**
 * Check if two date ranges overlap
 */
export function doDateRangesOverlap(
  range1Start: string | Date,
  range1End: string | Date,
  range2Start: string | Date,
  range2End: string | Date
): boolean {
  // Convert all inputs to Date objects for consistent comparison
  const start1 = range1Start instanceof Date ? range1Start : parseDate(range1Start);
  const end1 = range1End instanceof Date ? range1End : parseDate(range1End);
  const start2 = range2Start instanceof Date ? range2Start : parseDate(range2Start);
  const end2 = range2End instanceof Date ? range2End : parseDate(range2End);
  
  // Ranges overlap if one range's start is before the other's end
  // and one range's end is after the other's start
  return start1 <= end2 && end1 >= start2;
}

/**
 * Get today's date at midnight (for date comparisons)
 */
export function getTodayAtMidnight(): Date {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date;
}
