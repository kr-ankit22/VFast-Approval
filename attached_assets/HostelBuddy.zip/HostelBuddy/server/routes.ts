import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  BookingStatus, 
  insertBookingSchema, 
  bookingApprovalSchema,
  roomAllocationSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Check authentication middleware
  const checkAuth = (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Check specific role middleware
  const checkRole = (role: string) => {
    return (req: Request, res: Response, next: NextFunction) => {
      if (!req.isAuthenticated() || req.user.role !== role) {
        return res.status(403).json({ message: "Forbidden" });
      }
      next();
    };
  };

  // BOOKINGS API
  
  // Create a new booking
  app.post("/api/bookings", checkAuth, async (req, res, next) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      
      // Ensure the userId is set to the current user's ID
      bookingData.userId = req.user.id;
      
      // Normalize and validate dates (YYYY-MM-DD format)
      const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
      
      if (!dateRegex.test(bookingData.checkIn) || !dateRegex.test(bookingData.checkOut)) {
        return res.status(400).json({ 
          message: "Invalid date format. Please use YYYY-MM-DD format." 
        });
      }
      
      // Parse dates with consistent behavior (use UTC to avoid timezone issues)
      const checkInDate = new Date(bookingData.checkIn + 'T00:00:00Z');
      const checkOutDate = new Date(bookingData.checkOut + 'T00:00:00Z');
      
      // Secondary validation to ensure dates parsed correctly
      if (isNaN(checkInDate.getTime()) || isNaN(checkOutDate.getTime())) {
        return res.status(400).json({ 
          message: "Invalid date values. Please check your dates." 
        });
      }
      
      // Get current date with time set to midnight for comparison
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Ensure dates are not in the past
      if (checkInDate < today) {
        return res.status(400).json({ 
          message: "Check-in date cannot be in the past" 
        });
      }
      
      // Ensure checkout is after checkin
      if (checkOutDate <= checkInDate) {
        return res.status(400).json({ 
          message: "Check-out date must be after check-in date" 
        });
      }
      
      // Check if user already has a booking for these dates
      const existingBooking = await storage.findUserBookingInRange(
        req.user.id,
        bookingData.checkIn,
        bookingData.checkOut
      );
      
      if (existingBooking) {
        return res.status(400).json({ 
          message: "You already have a booking for these dates" 
        });
      }
      
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
    } catch (error) {
      console.error("Booking creation error:", error);
      
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      
      next(error);
    }
  });

  // Get user's bookings
  app.get("/api/bookings/user", checkAuth, async (req, res, next) => {
    try {
      const bookings = await storage.getBookingsByUserId(req.user.id);
      res.json(bookings);
    } catch (error) {
      next(error);
    }
  });

  // Get all bookings (admin and vfast only)
  app.get("/api/bookings", checkAuth, async (req, res, next) => {
    try {
      // Only admin and vfast roles can view all bookings
      if (req.user.role !== 'admin' && req.user.role !== 'vfast') {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const bookings = await storage.getBookings();
      
      // For vfast, show approved and allocated bookings
      if (req.user.role === 'vfast') {
        const relevantBookings = bookings.filter(b => 
          b.status === BookingStatus.APPROVED || b.status === BookingStatus.ALLOCATED
        );
        return res.json(relevantBookings);
      }
      
      res.json(bookings);
    } catch (error) {
      next(error);
    }
  });

  // Get a specific booking
  app.get("/api/bookings/:id", checkAuth, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const booking = await storage.getBookingById(id);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Users can only view their own bookings, admins and vfast can view any
      if (req.user.role === 'user' && booking.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      res.json(booking);
    } catch (error) {
      next(error);
    }
  });

  // Update booking status (admin only)
  app.put("/api/bookings/:id/status", checkRole('admin'), async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const approvalData = bookingApprovalSchema.parse(req.body);
      
      const updatedBooking = await storage.updateBookingStatus(
        id, 
        approvalData.status, 
        approvalData.adminNote
      );
      
      if (!updatedBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(updatedBooking);
    } catch (error) {
      next(error);
    }
  });

  // Assign room to booking (vfast only)
  app.put("/api/bookings/:id/allocate", checkRole('vfast'), async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const allocationData = roomAllocationSchema.parse(req.body);
      
      // First check if booking exists and is in approved status
      const booking = await storage.getBookingById(id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }

      // Validate room number format - support both FGH and VH buildings
      const roomRegex = /^(FGH-1[0-9]{2}|VH-2[0-9]{2})$/;
      if (!roomRegex.test(allocationData.roomNumber)) {
        return res.status(400).json({
          message: "Invalid room number format. Should be FGH-1xx (101-110) or VH-2xx (201-210)"
        });
      }
      
      // Validate room number is within available range
      const [building, numberStr] = allocationData.roomNumber.split('-');
      const roomNumber = parseInt(numberStr);
      
      if (building === 'FGH' && (roomNumber < 101 || roomNumber > 110)) {
        return res.status(400).json({
          message: "Room number out of range. Available FGH rooms are 101 to 110"
        });
      }
      
      if (building === 'VH' && (roomNumber < 201 || roomNumber > 210)) {
        return res.status(400).json({
          message: "Room number out of range. Available VH rooms are 201 to 210"
        });
      }
      
      // Check if room is already allocated for overlapping dates
      const existingBooking = await storage.findOverlappingBooking(
        allocationData.roomNumber,
        booking.checkIn,
        booking.checkOut
      );
      
      if (existingBooking) {
        return res.status(400).json({ 
          message: "Room is already allocated for these dates" 
        });
      }
      
      if (booking.status !== BookingStatus.APPROVED) {
        return res.status(400).json({ 
          message: "Only approved bookings can be allocated a room" 
        });
      }
      
      const updatedBooking = await storage.assignRoom(id, allocationData.roomNumber);
      
      if (!updatedBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(updatedBooking);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
