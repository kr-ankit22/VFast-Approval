import { bookings, users, type User, type InsertUser, type Booking, type InsertBooking, BookingStatus } from "@shared/schema";
import session from "express-session";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Booking operations
  getBookings(): Promise<Booking[]>;
  getBookingsByUserId(userId: number): Promise<Booking[]>;
  getBookingById(id: number): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: number, status: string, note?: string): Promise<Booking | undefined>;
  assignRoom(id: number, roomNumber: string): Promise<Booking | undefined>;

  // For authentication
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const now = new Date();
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        createdAt: now
      })
      .returning();
    return user;
  }

  // Booking operations
  async getBookings(): Promise<Booking[]> {
    return await db.select().from(bookings);
  }

  async getBookingsByUserId(userId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.userId, userId));
  }

  async getBookingById(id: number): Promise<Booking | undefined> {
    const result = await db.select().from(bookings).where(eq(bookings.id, id));
    return result[0];
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const now = new Date();
    const [booking] = await db
      .insert(bookings)
      .values({
        ...insertBooking,
        status: BookingStatus.PENDING,
        roomNumber: null,
        adminNote: null,
        createdAt: now,
        updatedAt: now
      })
      .returning();
    return booking;
  }

  async updateBookingStatus(id: number, status: string, note?: string): Promise<Booking | undefined> {
    const updateValues: Partial<Booking> = { 
      status,
      updatedAt: new Date()
    };

    if (note !== undefined) {
      updateValues.adminNote = note;
    }

    const [updatedBooking] = await db
      .update(bookings)
      .set(updateValues)
      .where(eq(bookings.id, id))
      .returning();

    return updatedBooking;
  }

  async findUserBookingInRange(userId: number, checkIn: string, checkOut: string): Promise<Booking | undefined> {
    // Normalize date formats to ensure consistent comparisons
    // This ensures we're always comparing YYYY-MM-DD strings
    const normalizeDate = (dateStr: string): string => {
      // Handle case where date might already be normalized
      if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        return dateStr;
      }
      // Otherwise normalize through Date object
      const date = new Date(dateStr);
      return date.toISOString().split('T')[0];
    };
    
    const checkInISO = normalizeDate(checkIn);
    const checkOutISO = normalizeDate(checkOut);
    
    // Find bookings with date ranges that overlap
    // Overlap occurs when:
    // 1. New check-in is before existing check-out AND
    // 2. New check-out is after existing check-in
    const existingBookings = await db
      .select()
      .from(bookings)
      .where(eq(bookings.userId, userId))
      .where(
        sql`(
          (${bookings.checkOut} >= ${checkInISO} AND ${bookings.checkIn} <= ${checkOutISO})
        )`
      );

    return existingBookings[0];
  }

  async findOverlappingBooking(roomNumber: string, checkIn: string, checkOut: string): Promise<Booking | undefined> {
    // Ensure dates are properly formatted and valid
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    
    // Convert to ISO strings for consistent comparisons
    const checkInISO = checkInDate.toISOString().split('T')[0];
    const checkOutISO = checkOutDate.toISOString().split('T')[0];
    
    // Check if the room is already booked for dates that would overlap with the requested dates
    // This query finds any booking where:
    // 1. The room number matches AND
    // 2. The booking is in an approved or allocated status AND
    // 3. The date ranges overlap (existing checkout >= requested checkin AND existing checkin <= requested checkout)
    const existingBookings = await db
      .select()
      .from(bookings)
      .where(eq(bookings.roomNumber, roomNumber))
      .where(
        sql`(
          (${bookings.checkOut} >= ${checkInISO} AND ${bookings.checkIn} <= ${checkOutISO})
          AND
          ${bookings.status} IN ('approved', 'allocated')
        )`
      );

    return existingBookings[0];
  }

  async assignRoom(id: number, roomNumber: string): Promise<Booking | undefined> {
    const [updatedBooking] = await db
      .update(bookings)
      .set({ 
        roomNumber,
        status: BookingStatus.ALLOCATED,
        updatedAt: new Date()
      })
      .where(eq(bookings.id, id))
      .returning();

    return updatedBooking;
  }
}

export const storage = new DatabaseStorage();