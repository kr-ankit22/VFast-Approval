import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User roles enum
export const UserRole = {
  USER: "user",
  ADMIN: "admin",
  VFAST: "vfast"
} as const;

export type UserRoleType = typeof UserRole[keyof typeof UserRole];

// Booking status enum
export const BookingStatus = {
  PENDING: "pending",
  APPROVED: "approved",
  REJECTED: "rejected",
  ALLOCATED: "allocated",
  CANCELLED: "cancelled"
} as const;

export type BookingStatusType = typeof BookingStatus[keyof typeof BookingStatus];

// User types enum
export const UserType = {
  INTERNAL: "internal",
  EXTERNAL: "external"
} as const;

export type UserTypeType = typeof UserType[keyof typeof UserType];

// Purpose of stay enum
export const StayPurpose = {
  ACADEMIC: "academic",
  CONFERENCE: "conference",
  PERSONAL: "personal",
  PROJECT: "project",
  OTHER: "other"
} as const;

export type StayPurposeType = typeof StayPurpose[keyof typeof StayPurpose];

// Department enum
export const Department = {
  CS: "Computer Science",
  EEE: "Electrical & Electronics",
  MECH: "Mechanical",
  CHEM: "Chemical",
  ECO: "Economics & Finance",
  OTHER: "Other"
} as const;

export type DepartmentType = typeof Department[keyof typeof Department];

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Bookings table
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  userType: text("user_type").notNull(),
  checkIn: text("check_in").notNull(),
  checkOut: text("check_out").notNull(),
  purpose: text("purpose").notNull(),
  department: text("department").notNull(),
  comments: text("comments"),
  status: text("status").notNull().default(BookingStatus.PENDING),
  roomNumber: text("room_number"),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  status: true,
  roomNumber: true,
  adminNote: true,
  createdAt: true,
  updatedAt: true,
  userId: true
});

export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

// Define relationships
export const usersRelations = relations(users, ({ many }) => ({
  bookings: many(bookings)
}));

export const bookingsRelations = relations(bookings, ({ one }) => ({
  user: one(users, {
    fields: [bookings.userId],
    references: [users.id]
  })
}));

// Extended booking with user information
export type BookingWithUser = Booking & {
  user: {
    name: string;
    email: string;
  }
};

// Room allocation schema
export const roomAllocationSchema = z.object({
  bookingId: z.number(),
  roomNumber: z.string().min(1, "Room number is required")
});

export type RoomAllocation = z.infer<typeof roomAllocationSchema>;

// Booking approval schema
export const bookingApprovalSchema = z.object({
  bookingId: z.number(),
  status: z.enum([BookingStatus.APPROVED, BookingStatus.REJECTED]),
  adminNote: z.string().optional()
});

export type BookingApproval = z.infer<typeof bookingApprovalSchema>;

// Login schema
export const loginSchema = z.object({
  email: z.string().email("Invalid email format"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

export type LoginData = z.infer<typeof loginSchema>;
